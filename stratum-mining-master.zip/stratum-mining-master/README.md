stratum-mining
==============

Demo implementation of novacoin mining pool using Stratum mining protocol.

For Stratum mining protocol specification, please visit http://mining.bitcoin.cz/stratum-mining.

Contact
-------

This pool implementation is provided by http://mining.bitcoin.cz. You can contact
me by email info(at)bitcoin.cz or on IRC #stratum on freenode.

Modified for novacoin by 0xDEADFACE. You can contact me by emain masmfan(at)gmail.com.

If you wish to support our project:

BTC: 1D4KaxBey7y9r11jXkMuQQhvwvMaa1HMWt
NVC: 4WpFe4iTc8zC3UHAzdQX6w9BcRuXFxvPqm
